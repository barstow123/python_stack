import parent as p


print(p.square(5))
user = p.User("Anna")
print(user.name)
print(user.say_hello())